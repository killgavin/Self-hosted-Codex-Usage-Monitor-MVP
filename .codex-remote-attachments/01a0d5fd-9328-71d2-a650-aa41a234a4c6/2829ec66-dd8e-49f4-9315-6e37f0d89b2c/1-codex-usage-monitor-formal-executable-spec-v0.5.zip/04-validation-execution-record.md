# Codex Usage Monitor — Validation Execution Record

- Version: 0.5
- Status: READY FOR EXECUTION
- Source: `03-formal-executable-specification.md`
- Purpose: Standard evidence record for Validation Gates. This is not an Implementation Plan.

## Rules

1. Do not mark PASS without evidence.
2. Do not infer missing evidence.
3. Record FAIL when a criterion is demonstrably not satisfied.
4. Record BLOCKED when the environment/prerequisite prevents execution.
5. Redact credentials, tokens, passwords, and sensitive identifiers.
6. A rerun supersedes an earlier result only when the new evidence is retained.

---

## Gate A — Windows Native Codex

**Status:** NOT RUN

### Environment

```text
Date:
Executor:
Windows version:
Architecture:
Codex version:
Codex executable:
Relevant non-secret configuration:
```

### Evidence Checklist

| Check | Result | Evidence reference / note |
|---|---|---|
| app-server starts | NOT RUN | |
| initialize succeeds | NOT RUN | |
| account/read succeeds | NOT RUN | |
| account/rateLimits/read succeeds | NOT RUN | |
| usable rate-limit state returned | NOT RUN | |
| required product state normalizable | NOT RUN | |

### Result

```text
Gate A: NOT RUN
```

**PASS rule:** every checklist item is PASS.

---

## Gate B — IIS Filesystem Publication

**Status:** NOT RUN

### Environment

```text
Date:
Executor:
Collector OS/runtime platform:
Target filesystem/share type:
Target directory (redact if required):
IIS relationship to target:
Credential mechanism (type only; never secret):
```

### Evidence Checklist

| Check | Result | Evidence reference / note |
|---|---|---|
| target directory writable | NOT RUN | |
| temp file can be created in target directory | NOT RUN | |
| temp file flush/close succeeds | NOT RUN | |
| final replace/rename succeeds | NOT RUN | |
| repeated publication succeeds | NOT RUN | |
| concurrent static reads never intentionally expose partial JSON | NOT RUN | |
| permission/credential model acceptable | NOT RUN | |

### Result

```text
Gate B: NOT RUN
```

**PASS rule:** every checklist item is PASS.

---

## Gate C — IIS HTTPS Distribution

**Status:** NOT RUN

### Environment

```text
Date:
Executor:
Public test endpoint: [REDACT IF REQUIRED]
IIS version:
Client/network used for external test:
```

### Evidence Checklist

| Check | Result | Evidence reference / note |
|---|---|---|
| external HTTPS GET succeeds | NOT RUN | |
| certificate behavior acceptable | NOT RUN | |
| JSON MIME/content type correct | NOT RUN | |
| Cache-Control behavior known | NOT RUN | |
| ETag and/or Last-Modified behavior known | NOT RUN | |
| replaced snapshot becomes observable | NOT RUN | |
| access-control policy explicitly approved | NOT RUN | |

### Result

```text
Gate C: NOT RUN
```

**PASS rule:** every checklist item is PASS.

---

## Overall Readiness

| Dependency | Status |
|---|---|
| Gate A — Windows Native Codex | NOT RUN |
| Gate B — IIS Filesystem Publication | NOT RUN |
| Gate C — IIS HTTPS Distribution | NOT RUN |
| Exact current.json wire contract | OPEN |
| Android technology | OPEN |
| Widget delivery phase | OPEN |
| Foreground refresh interval | OPEN |
| Stale threshold | OPEN |
| Heartbeat/status resource | OPEN |
| Optional FTP-family publisher | OPEN |

### Overall Result

```text
FORMAL SPECIFICATION: READY
VALIDATION EXECUTION: READY
FULL IMPLEMENTATION READINESS: NOT YET ESTABLISHED
```
